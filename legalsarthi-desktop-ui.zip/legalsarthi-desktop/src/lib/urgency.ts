/**
 * Urgency keyword matcher across English + Indic languages.
 * Returns true if the input contains a high-urgency phrase
 * (immediate danger, police, violence, etc.).
 */
const URGENCY_WORDS = [
  // English
  "danger", "police", "help me", "save me", "save my", "violence", "abuse",
  "beating", "beaten", "raped", "rape", "kidnap", "threaten", "threat",
  "molest", "harass", "attacked", "attack", "kill me", "killing", "blood",
  "emergency", "urgent", "sos", "trafficking", "kidnapped",
  // Hindi
  "खतरा", "पुलिस", "मदद", "बचाओ", "हिंसा", "मारपीट", "बलात्कार", "अपहरण",
  "धमकी", "आपातकाल", "जान",
  // Marathi
  "धोका", "मदत करा", "वाचवा", "हिंसा", "मारहाण", "धमकी",
  // Kannada
  "ಅಪಾಯ", "ಪೊಲೀಸ್", "ಸಹಾಯ", "ಉಳಿಸಿ", "ಹಿಂಸೆ", "ಬೆದರಿಕೆ",
  // Telugu
  "ప్రమాదం", "పోలీస్", "సహాయం", "రక్షించండి", "హింస", "బెదిరింపు",
  // Tamil
  "ஆபத்து", "காவல்", "உதவி", "காப்பாற்று", "வன்முறை", "மிரட்டல்",
];

export const detectUrgency = (text: string): boolean => {
  if (!text) return false;
  const lower = text.toLowerCase();
  return URGENCY_WORDS.some((w) => lower.includes(w.toLowerCase()));
};
